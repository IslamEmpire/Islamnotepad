package com.mofakkira.notes.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

sealed interface DeepLink {
    data class Note(val id: Long) : DeepLink
    data object Timer : DeepLink
}

@Composable
fun AppNav(deepLink: MutableState<DeepLink?>) {
    val nav = rememberNavController()
    val vm: AppViewModel = viewModel()

    LaunchedEffect(deepLink.value) {
        when (val d = deepLink.value) {
            is DeepLink.Note -> nav.navigate("editor/${d.id}")
            DeepLink.Timer -> nav.navigate("timer")
            null -> {}
        }
        deepLink.value = null
    }

    NavHost(navController = nav, startDestination = "list") {
        composable("list") {
            NotesListScreen(
                vm = vm,
                onOpen = { nav.navigate("editor/$it") },
                onNew = { nav.navigate("editor/-1") },
                onBackup = { nav.navigate("backup") },
                onLock = { nav.navigate("lock") },
                onTimer = { nav.navigate("timer") }
            )
        }
        composable(
            "editor/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { e ->
            EditorScreen(
                vm = vm,
                noteId = e.arguments?.getLong("id") ?: -1L,
                onBack = { nav.popBackStack() },
                // يُحفظ المحرر قبل الانتقال، لذا نعود للقائمة عند الرجوع
                onTimer = { id -> nav.navigate("timer?noteId=$id") { popUpTo("list") } },
                onLockSettings = { nav.navigate("lock") { popUpTo("list") } }
            )
        }
        composable("backup") { BackupScreen(vm) { nav.popBackStack() } }
        composable("lock") { LockScreen(vm) { nav.popBackStack() } }
        composable(
            "timer?noteId={noteId}",
            arguments = listOf(navArgument("noteId") {
                type = NavType.LongType
                defaultValue = -1L
            })
        ) { e ->
            TimerScreen(
                vm = vm,
                presetNoteId = e.arguments?.getLong("noteId") ?: -1L,
                onBack = { nav.popBackStack() },
                onOpenNote = { nav.navigate("editor/$it") }
            )
        }
    }
}
