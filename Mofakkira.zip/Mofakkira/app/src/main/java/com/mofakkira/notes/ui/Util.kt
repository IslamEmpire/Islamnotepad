package com.mofakkira.notes.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.fragment.app.FragmentActivity
import java.text.SimpleDateFormat
import java.util.Locale

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun Context.findFragmentActivity(): FragmentActivity? = findActivity() as? FragmentActivity

fun dateFormat(pattern: String = "d MMM yyyy"): SimpleDateFormat =
    SimpleDateFormat(pattern, Locale.forLanguageTag("ar"))
