package com.mofakkira.notes.ui

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

val Teal = Color(0xFF0F766E)
val Cream = Color(0xFFFBF8F3)

private val LightScheme = lightColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCEBE7),
    onPrimaryContainer = Color(0xFF00403B),
    secondaryContainer = Color(0xFFCCEBE7),
    onSecondaryContainer = Color(0xFF00403B),
    background = Cream,
    onBackground = Color(0xFF1C1B18),
    surface = Cream,
    onSurface = Color(0xFF1C1B18),
    surfaceVariant = Color(0xFFEFE9DF),
    onSurfaceVariant = Color(0xFF4F4B44),
    outline = Color(0xFFB5AEA2),
    surfaceContainerLow = Color(0xFFF5F0E8),
    surfaceContainer = Color(0xFFF1ECE3),
    surfaceContainerHigh = Color(0xFFEDE7DD),
    surfaceContainerHighest = Color(0xFFEAE4D9)
)

/**
 * خط Tajawal: ضع الملفات Tajawal-Regular.ttf و Tajawal-Medium.ttf و Tajawal-Bold.ttf
 * في app/src/main/assets/fonts/ . إن لم توجد يُستخدم الخط الافتراضي دون أي خطأ.
 */
private fun loadTajawal(ctx: Context): FontFamily {
    val files = try {
        ctx.assets.list("fonts")?.toSet() ?: emptySet()
    } catch (e: Exception) {
        emptySet()
    }
    fun font(name: String, weight: FontWeight): Font? =
        if (name in files) Font("fonts/$name", ctx.assets, weight) else null

    val list = listOfNotNull(
        font("Tajawal-Regular.ttf", FontWeight.Normal),
        font("Tajawal-Medium.ttf", FontWeight.Medium),
        font("Tajawal-Bold.ttf", FontWeight.Bold)
    )
    return if (list.isEmpty()) FontFamily.Default else FontFamily(list)
}

private fun Typography.withFont(f: FontFamily) = copy(
    displayLarge = displayLarge.copy(fontFamily = f),
    displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f),
    headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f),
    titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f),
    bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f),
    labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun NotesTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val typography = remember { Typography().withFont(loadTajawal(ctx)) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = LightScheme, typography = typography, content = content)
    }
}
