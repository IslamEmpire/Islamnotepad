package com.mofakkira.notes.timer

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.mofakkira.notes.MainActivity
import com.mofakkira.notes.R
import com.mofakkira.notes.data.AppDatabase
import com.mofakkira.notes.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * المؤقت يعتمد على AlarmManager (يعمل والتطبيق مغلق) مع وقت الانتهاء المخزّن في Prefs.
 * أثناء العدّ يظهر إشعار مستمر بعدّاد تنازلي، وعند الانتهاء يصدر إشعار تنبيه.
 */
object TimerController {
    private const val CH_RUN = "timer_running"
    private const val CH_DONE = "timer_done"
    private const val ID_RUN = 1001
    private const val ID_DONE = 1002

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_RUN, "المؤقت الجاري", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "انتهاء المؤقت", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun alarmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, TimerReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun openIntent(ctx: Context, noteId: Long): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_NOTE, noteId)
            putExtra(MainActivity.EXTRA_TIMER, noteId <= 0)
        }
        return PendingIntent.getActivity(
            ctx, 2, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun start(ctx: Context, minutes: Int, noteId: Long) {
        val total = minutes * 60_000L
        val end = System.currentTimeMillis() + total
        Prefs(ctx).apply {
            timerEnd = end
            timerTotal = total
            timerNote = noteId
            timerDone = false
        }
        schedule(ctx, end)
        showRunning(ctx, end, noteId)
    }

    private fun schedule(ctx: Context, end: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(ctx)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx))
        NotificationManagerCompat.from(ctx).cancel(ID_RUN)
        Prefs(ctx).apply {
            timerEnd = 0
            timerTotal = 0
            timerNote = -1
            timerDone = false
        }
    }

    @SuppressLint("MissingPermission")
    private fun showRunning(ctx: Context, end: Long, noteId: Long) {
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_RUN)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("المؤقت يعمل")
            .setContentText("العدّ التنازلي جارٍ")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(end)
            .setContentIntent(openIntent(ctx, noteId))
            .build()
        NotificationManagerCompat.from(ctx).notify(ID_RUN, n)
    }

    /** يُستدعى عند وصول التنبيه. لا يمسح الحالة؛ تبقى لتظهر «انتهى الوقت» داخل التطبيق. */
    @SuppressLint("MissingPermission")
    suspend fun finish(ctx: Context) {
        val p = Prefs(ctx)
        if (p.timerEnd <= 0 || p.timerDone) return
        p.timerDone = true
        ensureChannels(ctx)

        val noteId = p.timerNote
        val label: String? = if (noteId > 0) {
            val n = AppDatabase.get(ctx).notes().get(noteId)
            when {
                n == null -> null
                n.locked -> "ملاحظة مقفلة"
                else -> n.title.ifBlank { "ملاحظة بدون عنوان" }
            }
        } else null

        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("انتهى المؤقت")
            .setContentText(if (label != null) "الملاحظة المرتبطة: $label" else "انتهى الوقت المحدد")
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(openIntent(ctx, noteId))
            .build()
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_RUN)
        nm.notify(ID_DONE, n)
    }

    /** بعد إعادة تشغيل الجهاز. */
    suspend fun restore(ctx: Context) {
        val p = Prefs(ctx)
        if (p.timerEnd <= 0) return
        if (p.timerEnd > System.currentTimeMillis()) {
            schedule(ctx, p.timerEnd)
            showRunning(ctx, p.timerEnd, p.timerNote)
        } else if (!p.timerDone) {
            finish(ctx)
        }
    }
}

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                TimerController.finish(app)
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                TimerController.restore(app)
            } finally {
                pending.finish()
            }
        }
    }
}
