package com.mofakkira.notes.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mofakkira.notes.backup.AutoBackup
import com.mofakkira.notes.data.Note
import com.mofakkira.notes.data.NoteRepository
import com.mofakkira.notes.data.Prefs
import com.mofakkira.notes.security.Crypto
import com.mofakkira.notes.security.KeystoreBox
import com.mofakkira.notes.security.PinHasher
import com.mofakkira.notes.timer.TimerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class PinCheck(val ok: Boolean, val lockedSeconds: Int = 0, val attemptsLeft: Int = 0)

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = NoteRepository(app)
    private val prefs = Prefs(app)

    enum class Filter(val label: String) {
        ALL("الكل"), PINNED("المثبّتة"), LOCKED("المقفلة"), TODOS("قوائم مهام"), TEXT("نصية")
    }

    // ---------- الملاحظات ----------
    val query = MutableStateFlow("")
    val filter = MutableStateFlow(Filter.ALL)

    val allNotes: StateFlow<List<Note>> =
        repo.notes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val notes: StateFlow<List<Note>> = combine(allNotes, query, filter) { list, q0, f ->
        val q = q0.trim()
        list.filter { n ->
            val okFilter = when (f) {
                Filter.ALL -> true
                Filter.PINNED -> n.pinned
                Filter.LOCKED -> n.locked
                Filter.TODOS -> n.todoList().isNotEmpty()
                Filter.TEXT -> n.body.isNotBlank()
            }
            // لا يُبحث داخل محتوى الملاحظات المقفلة، فقط في عنوانها
            val okQuery = q.isEmpty() || n.title.contains(q, ignoreCase = true) ||
                (!n.locked && (n.body.contains(q, ignoreCase = true) ||
                    n.todoList().any { it.text.contains(q, ignoreCase = true) }))
            okFilter && okQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun load(id: Long): Note? = repo.get(id)

    fun save(n: Note) {
        viewModelScope.launch { repo.save(n) }
    }

    suspend fun saveNow(n: Note): Long {
        repo.save(n)
        return repo.getByUid(n.uid)?.id ?: -1L
    }

    fun delete(uid: String) {
        viewModelScope.launch { repo.deleteByUid(uid) }
    }

    // ---------- القفل ----------
    var hasPin by mutableStateOf(prefs.pinHash != null)
        private set
    var biometricOn by mutableStateOf(prefs.biometric)
        private set

    suspend fun checkPin(pin: String): PinCheck = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        if (prefs.lockUntil > now) {
            return@withContext PinCheck(false, ((prefs.lockUntil - now + 999) / 1000).toInt())
        }
        val saltStr = prefs.pinSalt
        val stored = prefs.pinHash
        if (saltStr == null || stored == null) return@withContext PinCheck(false)

        val candidate = PinHasher.hash(pin, Crypto.unb64(saltStr))
        val ok = MessageDigest.isEqual(candidate.toByteArray(), stored.toByteArray())
        if (ok) {
            prefs.failCount = 0
            prefs.lockLevel = 0
            PinCheck(true)
        } else {
            val fails = prefs.failCount + 1
            if (fails >= 5) {
                // كل 5 محاولات خاطئة: انتظار 30 ثانية يتضاعف في كل مرة (حتى حدّ أقصى)
                val level = prefs.lockLevel
                val wait = 30_000L shl level.coerceAtMost(6)
                prefs.lockUntil = now + wait
                prefs.lockLevel = level + 1
                prefs.failCount = 0
                PinCheck(false, (wait / 1000).toInt())
            } else {
                prefs.failCount = fails
                PinCheck(false, 0, 5 - fails)
            }
        }
    }

    suspend fun setPin(pin: String) {
        withContext(Dispatchers.Default) {
            val salt = Crypto.randomBytes(16)
            prefs.pinSalt = Crypto.b64(salt)
            prefs.pinHash = PinHasher.hash(pin, salt)
            prefs.failCount = 0
            prefs.lockLevel = 0
            prefs.lockUntil = 0
        }
        hasPin = true
    }

    fun setBiometric(on: Boolean) {
        prefs.biometric = on
        biometricOn = on
    }

    // ---------- النسخ الاحتياطي ----------
    suspend fun export(uri: Uri, password: CharArray?): Int = repo.exportTo(uri, password)
    suspend fun readBytes(uri: Uri): ByteArray = repo.readBytes(uri)
    suspend fun importBytes(bytes: ByteArray, password: CharArray?): Int =
        repo.importBytes(bytes, password)

    var autoOn by mutableStateOf(prefs.autoBackup)
        private set
    var autoFolderName by mutableStateOf(folderName())
        private set
    var lastAuto by mutableLongStateOf(prefs.lastAuto)
        private set
    var lastAutoOk by mutableStateOf(prefs.lastAutoOk)
        private set

    private fun folderName(): String? {
        val t = prefs.autoTree ?: return null
        return try {
            DocumentFile.fromTreeUri(app, Uri.parse(t))?.name
        } catch (e: Exception) {
            null
        }
    }

    fun enableAuto(tree: Uri, password: String?) {
        prefs.autoTree = tree.toString()
        prefs.autoPassSealed =
            if (password.isNullOrEmpty()) null else KeystoreBox.seal(password)
        prefs.autoBackup = true
        AutoBackup.schedule(app)
        autoOn = true
        autoFolderName = folderName()
    }

    fun disableAuto() {
        prefs.autoBackup = false
        AutoBackup.cancel(app)
        autoOn = false
    }

    suspend fun autoBackupNow(): Boolean {
        val ok = try {
            AutoBackup.runNow(app)
        } catch (e: Exception) {
            false
        }
        prefs.lastAuto = System.currentTimeMillis()
        prefs.lastAutoOk = ok
        lastAuto = prefs.lastAuto
        lastAutoOk = ok
        return ok
    }

    // ---------- المؤقت ----------
    var timerEnd by mutableLongStateOf(prefs.timerEnd)
        private set
    var timerTotal by mutableLongStateOf(prefs.timerTotal)
        private set
    var timerNote by mutableLongStateOf(prefs.timerNote)
        private set

    fun syncTimer() {
        timerEnd = prefs.timerEnd
        timerTotal = prefs.timerTotal
        timerNote = prefs.timerNote
    }

    fun startTimer(minutes: Int, noteId: Long) {
        TimerController.start(app, minutes, noteId)
        syncTimer()
    }

    fun cancelTimer() {
        TimerController.cancel(app)
        syncTimer()
    }
}
