package com.mofakkira.notes.data

import android.content.Context
import android.content.SharedPreferences

/** إعدادات التطبيق (الرمز مخزّن مجزّأً فقط، ولا يُخزَّن الرمز نفسه). */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("mofakkira", Context.MODE_PRIVATE)

    private fun str(k: String) = sp.getString(k, null)
    private fun putStr(k: String, v: String?) = sp.edit().putString(k, v).apply()
    private fun lng(k: String, d: Long = 0L) = sp.getLong(k, d)
    private fun putLng(k: String, v: Long) = sp.edit().putLong(k, v).apply()
    private fun bool(k: String) = sp.getBoolean(k, false)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var pinHash: String?
        get() = str("pin_hash")
        set(v) = putStr("pin_hash", v)
    var pinSalt: String?
        get() = str("pin_salt")
        set(v) = putStr("pin_salt", v)
    var biometric: Boolean
        get() = bool("biometric")
        set(v) = putBool("biometric", v)
    var failCount: Int
        get() = sp.getInt("fail_count", 0)
        set(v) = sp.edit().putInt("fail_count", v).apply()
    var lockLevel: Int
        get() = sp.getInt("lock_level", 0)
        set(v) = sp.edit().putInt("lock_level", v).apply()
    var lockUntil: Long
        get() = lng("lock_until")
        set(v) = putLng("lock_until", v)

    var autoBackup: Boolean
        get() = bool("auto_backup")
        set(v) = putBool("auto_backup", v)
    var autoTree: String?
        get() = str("auto_tree")
        set(v) = putStr("auto_tree", v)
    var autoPassSealed: String?
        get() = str("auto_pass")
        set(v) = putStr("auto_pass", v)
    var lastAuto: Long
        get() = lng("last_auto")
        set(v) = putLng("last_auto", v)
    var lastAutoOk: Boolean
        get() = bool("last_auto_ok")
        set(v) = putBool("last_auto_ok", v)

    var timerEnd: Long
        get() = lng("timer_end")
        set(v) = putLng("timer_end", v)
    var timerTotal: Long
        get() = lng("timer_total")
        set(v) = putLng("timer_total", v)
    var timerNote: Long
        get() = lng("timer_note", -1L)
        set(v) = putLng("timer_note", v)
    var timerDone: Boolean
        get() = bool("timer_done")
        set(v) = putBool("timer_done", v)
}
