package com.mofakkira.notes.ui

import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mofakkira.notes.data.Note
import com.mofakkira.notes.data.Todo
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    vm: AppViewModel,
    noteId: Long,
    onBack: () -> Unit,
    onTimer: (Long) -> Unit,
    onLockSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }

    var loaded by remember { mutableStateOf(false) }
    var authed by remember { mutableStateOf(false) }
    var base by remember { mutableStateOf(Note()) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    val todos = remember { mutableStateListOf<Todo>() }
    var pinned by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(false) }
    var savedOnce by remember { mutableStateOf(noteId > 0) }
    var deleted by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var needPin by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (noteId > 0) {
            vm.load(noteId)?.let {
                base = it
                title = it.title
                body = it.body
                todos.clear()
                todos.addAll(it.todoList())
                pinned = it.pinned
                locked = it.locked
                authed = !it.locked
            }
        } else {
            authed = true
        }
        loaded = true
    }

    // منع لقطات الشاشة وتصوير النوافذ الأخيرة طالما الملاحظة مقفلة
    DisposableEffect(locked) {
        val window = ctx.findActivity()?.window
        if (locked) window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun current() = base.copy(
        title = title.trim(),
        body = body,
        todosJson = Todo.encode(todos.filter { it.text.isNotBlank() }),
        pinned = pinned,
        locked = locked,
        updatedAt = System.currentTimeMillis()
    )

    fun isEmpty() = title.isBlank() && body.isBlank() && todos.none { it.text.isNotBlank() }

    fun persist() {
        if (!loaded || !authed || deleted) return
        if (isEmpty() && !savedOnce) return
        savedOnce = true
        vm.save(current())
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { persist() }
    BackHandler { persist(); onBack() }

    if (!loaded || (locked && !authed)) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { }
        if (loaded) AuthGate(vm, onSuccess = { authed = true }, onDismiss = onBack)
        return
    }

    val clear = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = { persist(); onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            Icons.Default.PushPin, if (pinned) "إلغاء التثبيت" else "تثبيت",
                            tint = if (pinned) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = {
                        if (!vm.hasPin) needPin = true else locked = !locked
                    }) {
                        Icon(
                            if (locked) Icons.Default.Lock else Icons.Default.LockOpen,
                            if (locked) "إلغاء قفل الملاحظة" else "قفل الملاحظة",
                            tint = if (locked) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = {
                        if (isEmpty() && !savedOnce) {
                            scope.launch { snack.showSnackbar("اكتب شيئاً أولاً ثم اربط المؤقت") }
                        } else scope.launch {
                            savedOnce = true
                            val id = vm.saveNow(current())
                            if (id > 0) onTimer(id)
                        }
                    }) { Icon(Icons.Default.Timer, "مؤقت لهذه الملاحظة") }
                    if (savedOnce) IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, "حذف")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 8.dp)
        ) {
            TextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("العنوان", style = MaterialTheme.typography.headlineSmall) },
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                singleLine = true,
                colors = clear
            )
            TextField(
                value = body,
                onValueChange = { body = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                placeholder = { Text("اكتب ملاحظتك هنا…") },
                colors = clear
            )
            HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 8.dp))
            Text(
                "قائمة المهام",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            todos.forEachIndexed { i, t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = t.done, onCheckedChange = { todos[i] = t.copy(done = it) })
                    TextField(
                        value = t.text,
                        onValueChange = { todos[i] = t.copy(text = it) },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("مهمة") },
                        textStyle = LocalTextStyle.current.copy(
                            textDecoration = if (t.done) TextDecoration.LineThrough
                            else TextDecoration.None
                        ),
                        singleLine = true,
                        colors = clear
                    )
                    IconButton(onClick = { todos.removeAt(i) }) {
                        Icon(Icons.Default.Close, "حذف المهمة")
                    }
                }
            }
            TextButton(
                onClick = { todos.add(Todo("", false)) },
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.size(8.dp))
                Text("إضافة مهمة")
            }
            Spacer(Modifier.size(48.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف الملاحظة؟") },
            text = { Text("لا يمكن التراجع عن الحذف.") },
            confirmButton = {
                TextButton(onClick = {
                    deleted = true
                    vm.delete(base.uid)
                    confirmDelete = false
                    onBack()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }

    if (needPin) {
        AlertDialog(
            onDismissRequest = { needPin = false },
            title = { Text("اضبط الرمز السري أولاً") },
            text = { Text("لقفل الملاحظات يلزم رمز سري من 4 أرقام. يمكنك ضبطه الآن من شاشة القفل.") },
            confirmButton = {
                TextButton(onClick = {
                    needPin = false
                    persist()
                    onLockSettings()
                }) { Text("ضبط الرمز") }
            },
            dismissButton = { TextButton(onClick = { needPin = false }) { Text("لاحقاً") } }
        )
    }
}
