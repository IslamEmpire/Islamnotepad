package com.mofakkira.notes.data

import android.content.Context
import android.net.Uri
import com.mofakkira.notes.backup.BackupCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class NoteRepository(private val ctx: Context) {
    private val dao = AppDatabase.get(ctx).notes()

    val notes: Flow<List<Note>> = dao.observeAll()

    suspend fun get(id: Long): Note? = dao.get(id)

    suspend fun getByUid(uid: String): Note? = dao.getByUid(uid)

    /** الحفظ بحسب uid الثابت، فلا تتكرر الملاحظة مهما تعددت عمليات الحفظ. */
    suspend fun save(n: Note) {
        val ex = dao.getByUid(n.uid)
        dao.upsert(n.copy(id = ex?.id ?: 0, createdAt = ex?.createdAt ?: n.createdAt))
    }

    suspend fun deleteByUid(uid: String) = dao.deleteByUid(uid)

    suspend fun exportTo(uri: Uri, password: CharArray?): Int = withContext(Dispatchers.IO) {
        val all = dao.all()
        val bytes = BackupCodec.encode(all, password)
        val out = ctx.contentResolver.openOutputStream(uri, "wt")
            ?: throw java.io.IOException("تعذّر فتح الملف للكتابة")
        out.use { it.write(bytes) }
        all.size
    }

    suspend fun readBytes(uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("تعذّر فتح الملف للقراءة")
        input.use { it.readBytes() }
    }

    /** يدمج النسخة: يضيف الجديد ويحدّث الأقدم فقط، ولا يحذف شيئاً. */
    suspend fun importBytes(bytes: ByteArray, password: CharArray?): Int =
        withContext(Dispatchers.IO) {
            val incoming = BackupCodec.decode(bytes, password)
            var count = 0
            for (n in incoming) {
                val ex = dao.getByUid(n.uid)
                if (ex == null || n.updatedAt >= ex.updatedAt) {
                    dao.upsert(n.copy(id = ex?.id ?: 0))
                    count++
                }
            }
            count
        }
}
