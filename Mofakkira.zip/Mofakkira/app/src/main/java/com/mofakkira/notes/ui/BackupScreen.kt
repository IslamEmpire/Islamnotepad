package com.mofakkira.notes.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.mofakkira.notes.backup.BackupCodec
import kotlinx.coroutines.launch
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val fmt = remember { dateFormat("d MMM yyyy، HH:mm") }

    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf<ByteArray?>(null) }
    var importPass by remember { mutableStateOf("") }
    var importErr by remember { mutableStateOf<String?>(null) }
    var pendingTree by remember { mutableStateOf<Uri?>(null) }
    var autoPass by remember { mutableStateOf("") }

    fun say(msg: String) { scope.launch { snack.showSnackbar(msg) } }

    fun friendly(e: Throwable): String = when (e) {
        is BackupCodec.WrongPassword -> "كلمة المرور غير صحيحة"
        is BackupCodec.BadBackup -> "الملف ليس نسخة احتياطية صالحة"
        else -> "تعذّرت العملية: ${e.message ?: ""}"
    }

    // ----- تصدير -----
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            try {
                val n = vm.export(uri, if (pass.isEmpty()) null else pass.toCharArray())
                say("تم تصدير $n ملاحظة")
            } catch (e: Exception) {
                say(friendly(e))
            }
            busy = false
        }
    }

    // ----- استرجاع -----
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            try {
                val bytes = vm.readBytes(uri)
                if (BackupCodec.isEncrypted(bytes)) {
                    importPass = ""
                    importErr = null
                    pendingImport = bytes
                } else {
                    val n = vm.importBytes(bytes, null)
                    say("تم استرجاع $n ملاحظة")
                }
            } catch (e: Exception) {
                say(friendly(e))
            }
            busy = false
        }
    }

    // ----- نسخ تلقائي -----
    val treeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) { /* قد لا تكون قابلة للحفظ */ }
            autoPass = ""
            pendingTree = uri
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("النسخ الاحتياطي", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val cardColors = CardDefaults.cardColors(containerColor = Color.White)

            Card(Modifier.fillMaxWidth(), colors = cardColors) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تصدير إلى ملف", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "يُحفظ كل ما في المفكرة في ملف JSON على هاتفك. الملاحظات المقفلة تُحفظ " +
                            "داخل الملف أيضاً، فاستخدم كلمة مرور لتشفيره وحمايتها.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pass, onValueChange = { pass = it },
                        label = { Text("كلمة مرور التشفير (اختياري)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pass.isNotEmpty()) OutlinedTextField(
                        value = pass2, onValueChange = { pass2 = it },
                        label = { Text("تأكيد كلمة المرور") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        enabled = !busy,
                        onClick = {
                            if (pass.isNotEmpty() && pass != pass2) {
                                say("كلمتا المرور غير متطابقتين")
                            } else {
                                val stamp = dateFormat("yyyyMMdd-HHmm").format(Date())
                                exportLauncher.launch("mofakkira-backup-$stamp.json")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (pass.isEmpty()) "تصدير" else "تصدير مشفّراً") }
                }
            }

            Card(Modifier.fillMaxWidth(), colors = cardColors) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("استرجاع من ملف", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "يُدمج محتوى الملف مع ملاحظاتك الحالية: تُضاف الملاحظات الجديدة وتُحدَّث " +
                            "القديمة، ولا يُحذف شيء.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        enabled = !busy,
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("اختيار ملف نسخة احتياطية") }
                }
            }

            Card(Modifier.fillMaxWidth(), colors = cardColors) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("نسخ تلقائي أسبوعي", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (vm.autoOn) "المجلد: ${vm.autoFolderName ?: "غير معروف"}"
                                else "اختر مجلداً ليُحفظ فيه ملف النسخة كل أسبوع",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = vm.autoOn,
                            onCheckedChange = { on ->
                                if (on) treeLauncher.launch(null) else vm.disableAuto()
                            }
                        )
                    }
                    if (vm.autoOn) {
                        if (vm.lastAuto > 0) Text(
                            "آخر محاولة: ${fmt.format(Date(vm.lastAuto))} — " +
                                if (vm.lastAutoOk) "نجحت" else "فشلت",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "يعيد النظام جدولة المهمة حسب حالة البطارية، فقد يتأخر التنفيذ قليلاً.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            enabled = !busy,
                            onClick = {
                                scope.launch {
                                    busy = true
                                    val ok = vm.autoBackupNow()
                                    say(if (ok) "تم حفظ النسخة في المجلد" else "تعذّر حفظ النسخة، تحقق من المجلد")
                                    busy = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("نسخ الآن") }
                    }
                }
            }
        }
    }

    // كلمة مرور الملف المشفّر عند الاسترجاع
    pendingImport?.let { bytes ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("النسخة مشفّرة") },
            text = {
                OutlinedTextField(
                    value = importPass, onValueChange = { importPass = it; importErr = null },
                    label = { Text("كلمة المرور") },
                    singleLine = true,
                    isError = importErr != null,
                    supportingText = { importErr?.let { Text(it) } },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            val n = vm.importBytes(bytes, importPass.toCharArray())
                            pendingImport = null
                            say("تم استرجاع $n ملاحظة")
                        } catch (e: BackupCodec.WrongPassword) {
                            importErr = "كلمة المرور غير صحيحة"
                        } catch (e: Exception) {
                            pendingImport = null
                            say(friendly(e))
                        }
                    }
                }) { Text("استرجاع") }
            },
            dismissButton = { TextButton(onClick = { pendingImport = null }) { Text("إلغاء") } }
        )
    }

    // خيار تشفير النسخ التلقائية بعد اختيار المجلد
    pendingTree?.let { tree ->
        AlertDialog(
            onDismissRequest = { pendingTree = null },
            title = { Text("حماية النسخ التلقائية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "اترك الحقل فارغاً لحفظ النسخ بدون تشفير. تُخزَّن كلمة المرور محمية " +
                            "بمفتاح Android Keystore، وتحتاجها عند الاسترجاع.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = autoPass, onValueChange = { autoPass = it },
                        label = { Text("كلمة المرور (اختياري)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        vm.enableAuto(tree, autoPass)
                        say("تم تفعيل النسخ الأسبوعي")
                    } catch (e: Exception) {
                        say(friendly(e))
                    }
                    pendingTree = null
                }) { Text("تفعيل") }
            },
            dismissButton = { TextButton(onClick = { pendingTree = null }) { Text("إلغاء") } }
        )
    }
}
