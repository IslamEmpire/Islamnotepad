package com.mofakkira.notes

import android.app.Application
import com.mofakkira.notes.timer.TimerController

class NotesApp : Application() {
    override fun onCreate() {
        super.onCreate()
        TimerController.ensureChannels(this)
    }
}
