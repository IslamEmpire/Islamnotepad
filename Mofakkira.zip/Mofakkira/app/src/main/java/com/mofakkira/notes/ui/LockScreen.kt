package com.mofakkira.notes.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mofakkira.notes.security.Biometrics
import kotlinx.coroutines.launch

private enum class Step { HOME, VERIFY_OLD, NEW, CONFIRM }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }

    var step by remember { mutableStateOf(Step.HOME) }
    var firstPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var counter by remember { mutableIntStateOf(0) }

    val bioAvailable = remember { Biometrics.available(ctx) }

    fun goHome() { step = Step.HOME; error = null; firstPin = "" }
    fun bump() { counter++ }

    BackHandler(enabled = step != Step.HOME) { goHome() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("القفل", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = { if (step == Step.HOME) onBack() else goHome() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (step) {
                Step.HOME -> {
                    val cardColors = CardDefaults.cardColors(containerColor = Color.White)
                    Card(Modifier.fillMaxWidth(), colors = cardColors) {
                        Column(
                            Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("الرمز السري", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (vm.hasPin) "الرمز مضبوط. يُخزَّن مجزّأً ولا يمكن استرجاعه، " +
                                    "فإن نسيته لن تُفتح الملاحظات المقفلة."
                                else "لم يُضبط رمز بعد. اضبط رمزاً من 4 أرقام لتتمكن من قفل الملاحظات.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = {
                                    error = null
                                    step = if (vm.hasPin) Step.VERIFY_OLD else Step.NEW
                                    bump()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (vm.hasPin) "تغيير الرمز" else "ضبط الرمز") }
                        }
                    }
                    Card(Modifier.fillMaxWidth(), colors = cardColors) {
                        Row(
                            Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("بصمة الإصبع", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    when {
                                        !bioAvailable -> "غير متاحة: لا توجد بصمة مسجّلة أو الجهاز لا يدعمها"
                                        !vm.hasPin -> "اضبط الرمز السري أولاً"
                                        else -> "فتح الملاحظات المقفلة بالبصمة، والرمز يبقى بديلاً"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = vm.biometricOn,
                                enabled = bioAvailable && vm.hasPin,
                                onCheckedChange = { on ->
                                    if (!on) vm.setBiometric(false)
                                    else ctx.findFragmentActivity()?.let { act ->
                                        // نتأكد من البصمة مرة واحدة قبل التفعيل
                                        Biometrics.prompt(act, "تأكيد البصمة") {
                                            vm.setBiometric(true)
                                        }
                                    }
                                }
                            )
                        }
                    }
                    Card(Modifier.fillMaxWidth(), colors = cardColors) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("كيف يعمل القفل", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "• القفل لكل ملاحظة على حدة من زر القفل داخل المحرر.\n" +
                                    "• الملاحظة المقفلة يُخفى محتواها في القائمة ولا يُبحث داخلها.\n" +
                                    "• تُمنع لقطات الشاشة وتصوير النوافذ الأخيرة أثناء عرضها.\n" +
                                    "• بعد 5 محاولات خاطئة يُمنع الإدخال مدة تتضاعف.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Step.VERIFY_OLD -> PinEntry(
                    title = "أدخل الرمز الحالي", error = error,
                    resetKey = Step.VERIFY_OLD.ordinal * 1000 + counter
                ) { pin ->
                    scope.launch {
                        val r = vm.checkPin(pin)
                        if (r.ok) { error = null; step = Step.NEW; bump() }
                        else {
                            error = if (r.lockedSeconds > 0) "انتظر ${r.lockedSeconds} ثانية"
                            else "الرمز غير صحيح (المتبقي ${r.attemptsLeft})"
                            bump()
                        }
                    }
                }

                Step.NEW -> PinEntry(
                    title = "أدخل رمزاً جديداً من 4 أرقام", error = error,
                    resetKey = Step.NEW.ordinal * 1000 + counter
                ) { pin ->
                    firstPin = pin
                    error = null
                    step = Step.CONFIRM
                    bump()
                }

                Step.CONFIRM -> PinEntry(
                    title = "أعد إدخال الرمز للتأكيد", error = error,
                    resetKey = Step.CONFIRM.ordinal * 1000 + counter
                ) { pin ->
                    if (pin == firstPin) {
                        scope.launch {
                            vm.setPin(pin)
                            goHome()
                            snack.showSnackbar("تم حفظ الرمز السري")
                        }
                    } else {
                        error = "الرمزان غير متطابقين، ابدأ من جديد"
                        firstPin = ""
                        step = Step.NEW
                        bump()
                    }
                }
            }
        }
    }
}
