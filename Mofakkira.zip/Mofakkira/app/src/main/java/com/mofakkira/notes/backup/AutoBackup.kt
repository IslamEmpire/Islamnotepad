package com.mofakkira.notes.backup

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mofakkira.notes.data.AppDatabase
import com.mofakkira.notes.data.Prefs
import com.mofakkira.notes.security.KeystoreBox
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

object AutoBackup {
    private const val WORK = "auto_backup"
    private const val FILE_NAME = "mofakkira-auto-backup"

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(7, TimeUnit.DAYS).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            WORK, ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
    }

    /** يكتب نسخة واحدة في المجلد المختار (تستبدل النسخة السابقة). */
    suspend fun runNow(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        val prefs = Prefs(ctx)
        val tree = prefs.autoTree ?: return@withContext false
        val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(tree)) ?: return@withContext false
        if (!dir.canWrite()) return@withContext false

        val password = prefs.autoPassSealed?.let { KeystoreBox.open(it).toCharArray() }
        val notes = AppDatabase.get(ctx).notes().all()
        val bytes = BackupCodec.encode(notes, password)

        dir.findFile("$FILE_NAME.json")?.delete()
        val file = dir.createFile("application/json", FILE_NAME) ?: return@withContext false
        val out = ctx.contentResolver.openOutputStream(file.uri, "wt") ?: return@withContext false
        out.use { it.write(bytes) }
        true
    }
}

class AutoBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ok = try {
            AutoBackup.runNow(applicationContext)
        } catch (e: Exception) {
            false
        }
        val prefs = Prefs(applicationContext)
        prefs.lastAuto = System.currentTimeMillis()
        prefs.lastAutoOk = ok
        return if (ok) Result.success() else Result.failure()
    }
}
