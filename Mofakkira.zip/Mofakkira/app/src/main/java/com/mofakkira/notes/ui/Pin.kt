package com.mofakkira.notes.ui

import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogWindowProvider
import com.mofakkira.notes.security.Biometrics
import kotlinx.coroutines.launch

/** لوحة إدخال رمز من 4 أرقام. غيّر resetKey لتصفير الخانات. */
@Composable
fun PinEntry(
    title: String,
    error: String?,
    resetKey: Int,
    enabled: Boolean = true,
    onComplete: (String) -> Unit
) {
    var pin by remember(resetKey) { mutableStateOf("") }
    LaunchedEffect(pin) { if (pin.length == 4) onComplete(pin) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(4) { i ->
                Box(
                    Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (i < pin.length) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                )
            }
        }
        Text(
            error ?: " ",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
        // الأرقام تبقى بترتيب 1-2-3 المعتاد حتى في الواجهة العربية
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("", "0", "<")
                ).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { k ->
                            if (k.isEmpty()) {
                                Spacer(Modifier.size(68.dp))
                            } else {
                                Box(
                                    Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable(enabled = enabled) {
                                            if (k == "<") pin = pin.dropLast(1)
                                            else if (pin.length < 4) pin += k
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (k == "<") Icon(
                                        Icons.AutoMirrored.Filled.Backspace, "حذف"
                                    )
                                    else Text(k, style = MaterialTheme.typography.titleLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** نافذة التحقق (رمز + بصمة اختيارية). إن لم يُضبط رمز على الجهاز لا يوجد ما يُتحقَّق منه. */
@Composable
fun AuthGate(vm: AppViewModel, onSuccess: () -> Unit, onDismiss: () -> Unit) {
    if (!vm.hasPin) {
        LaunchedEffect(Unit) { onSuccess() }
        return
    }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    val canBio = remember { vm.biometricOn && Biometrics.available(ctx) }

    fun promptBio() {
        ctx.findFragmentActivity()?.let {
            Biometrics.prompt(it, "فتح الملاحظة المقفلة", onSuccess)
        }
    }
    LaunchedEffect(Unit) { if (canBio) promptBio() }

    Dialog(onDismissRequest = onDismiss) {
        // منع لقطات الشاشة لنافذة الرمز أيضاً
        (LocalView.current.parent as? DialogWindowProvider)?.window
            ?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PinEntry(title = "أدخل الرمز السري", error = error, resetKey = attempt) { pin ->
                    scope.launch {
                        val r = vm.checkPin(pin)
                        if (r.ok) {
                            onSuccess()
                        } else {
                            error = when {
                                r.lockedSeconds > 0 -> "محاولات كثيرة. انتظر ${r.lockedSeconds} ثانية"
                                else -> "الرمز غير صحيح (المتبقي ${r.attemptsLeft})"
                            }
                            attempt++
                        }
                    }
                }
                if (canBio) {
                    TextButton(onClick = { promptBio() }) {
                        Icon(Icons.Default.Fingerprint, null)
                        Spacer(Modifier.size(8.dp))
                        Text("استخدام البصمة")
                    }
                }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        }
    }
}
