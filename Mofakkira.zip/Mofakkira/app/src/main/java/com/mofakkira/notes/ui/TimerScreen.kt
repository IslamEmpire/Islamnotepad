package com.mofakkira.notes.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.Locale

private fun clock(ms: Long): String {
    val s = (ms + 999) / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerScreen(
    vm: AppViewModel,
    presetNoteId: Long,
    onBack: () -> Unit,
    onOpenNote: (Long) -> Unit
) {
    val ctx = LocalContext.current
    val notes by vm.allNotes.collectAsState()

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            vm.syncTimer()
            delay(250)
        }
    }

    var minutes by remember { mutableIntStateOf(25) }
    var custom by remember { mutableStateOf(false) }
    var customText by remember { mutableStateOf("") }
    var linkId by remember { mutableLongStateOf(if (presetNoteId > 0) presetNoteId else -1L) }
    var menu by remember { mutableStateOf(false) }

    val effective = if (custom) customText.toIntOrNull() ?: 0 else minutes
    val valid = effective in 1..600

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> vm.startTimer(effective, linkId) }

    fun begin() {
        if (!valid) return
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else vm.startTimer(effective, linkId)
    }

    fun noteLabel(id: Long): String {
        val n = notes.firstOrNull { it.id == id } ?: return "بدون ربط"
        return if (n.locked) "ملاحظة مقفلة" else n.title.ifBlank { "ملاحظة بدون عنوان" }
    }

    val running = vm.timerEnd > 0
    val remaining = (vm.timerEnd - now).coerceAtLeast(0L)
    val finished = running && remaining == 0L

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("المؤقت", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (running) {
                val fraction =
                    if (vm.timerTotal > 0) remaining.toFloat() / vm.timerTotal.toFloat() else 0f
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier.size(240.dp),
                        strokeWidth = 10.dp,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Text(
                        if (finished) "انتهى" else clock(remaining),
                        fontSize = if (finished) 40.sp else 48.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (vm.timerNote > 0) {
                    OutlinedButton(onClick = { onOpenNote(vm.timerNote) }) {
                        Text("الملاحظة: ${noteLabel(vm.timerNote)}")
                    }
                }
                Button(
                    onClick = { vm.cancelTimer() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (finished) "إغلاق" else "إيقاف المؤقت") }
            } else {
                Text("اختر المدة", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 25, 45).forEach { m ->
                        FilterChip(
                            selected = !custom && minutes == m,
                            onClick = { custom = false; minutes = m },
                            label = { Text("$m دقيقة") }
                        )
                    }
                    FilterChip(
                        selected = custom,
                        onClick = { custom = true },
                        label = { Text("مخصص") }
                    )
                }
                if (custom) OutlinedTextField(
                    value = customText,
                    onValueChange = { v -> customText = v.filter { it.isDigit() }.take(3) },
                    label = { Text("المدة بالدقائق (1 إلى 600)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("ربط بملاحظة (اختياري)", style = MaterialTheme.typography.titleSmall)
                Box {
                    OutlinedButton(onClick = { menu = true }) {
                        Text(noteLabel(linkId))
                        Icon(Icons.Default.ArrowDropDown, null)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("بدون ربط") },
                            onClick = { linkId = -1L; menu = false }
                        )
                        notes.forEach { n ->
                            DropdownMenuItem(
                                text = {
                                    Text(n.title.ifBlank { "ملاحظة بدون عنوان" } +
                                        if (n.locked) " (مقفلة)" else "")
                                },
                                onClick = { linkId = n.id; menu = false }
                            )
                        }
                    }
                }

                Button(
                    onClick = { begin() },
                    enabled = valid,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ابدأ المؤقت") }
                Text(
                    "يعمل المؤقت في الخلفية ويُرسل إشعاراً عند الانتهاء.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
