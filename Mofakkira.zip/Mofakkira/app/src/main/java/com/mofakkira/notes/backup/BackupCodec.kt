package com.mofakkira.notes.backup

import com.mofakkira.notes.data.Note
import com.mofakkira.notes.security.Crypto
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * صيغة الملف (JSON):
 * { format, version, exportedAt, encrypted, notes[] }  أو عند التشفير:
 * { ..., encrypted:true, kdf, iterations, salt, iv, data }  (AES-256-GCM)
 */
object BackupCodec {
    private const val FORMAT = "mofakkira-backup"
    private const val ITERATIONS = 150_000

    class BadBackup(msg: String) : Exception(msg)
    class WrongPassword : Exception()

    fun encode(notes: List<Note>, password: CharArray?): ByteArray {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(
                JSONObject()
                    .put("uid", n.uid)
                    .put("title", n.title)
                    .put("body", n.body)
                    .put("todos", JSONArray(n.todosJson))
                    .put("pinned", n.pinned)
                    .put("locked", n.locked)
                    .put("createdAt", n.createdAt)
                    .put("updatedAt", n.updatedAt)
            )
        }
        val root = JSONObject()
            .put("format", FORMAT)
            .put("version", 1)
            .put("exportedAt", System.currentTimeMillis())

        if (password == null) {
            root.put("encrypted", false).put("notes", arr)
        } else {
            val salt = Crypto.randomBytes(16)
            val iv = Crypto.randomBytes(12)
            val key = SecretKeySpec(Crypto.pbkdf2(password, salt, ITERATIONS), "AES")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
            val ct = cipher.doFinal(arr.toString().toByteArray(Charsets.UTF_8))
            root.put("encrypted", true)
                .put("kdf", "PBKDF2-HMAC-SHA256")
                .put("iterations", ITERATIONS)
                .put("salt", Crypto.b64(salt))
                .put("iv", Crypto.b64(iv))
                .put("data", Crypto.b64(ct))
        }
        return root.toString(2).toByteArray(Charsets.UTF_8)
    }

    private fun parse(bytes: ByteArray): JSONObject {
        try {
            val root = JSONObject(String(bytes, Charsets.UTF_8))
            if (root.optString("format") != FORMAT) throw BadBackup("صيغة غير معروفة")
            return root
        } catch (e: JSONException) {
            throw BadBackup("ملف غير صالح")
        }
    }

    fun isEncrypted(bytes: ByteArray): Boolean = parse(bytes).optBoolean("encrypted", false)

    fun decode(bytes: ByteArray, password: CharArray?): List<Note> {
        val root = parse(bytes)
        try {
            val arr: JSONArray = if (root.optBoolean("encrypted", false)) {
                if (password == null) throw WrongPassword()
                val salt = Crypto.unb64(root.getString("salt"))
                val iv = Crypto.unb64(root.getString("iv"))
                val data = Crypto.unb64(root.getString("data"))
                val iterations = root.optInt("iterations", ITERATIONS)
                val key = SecretKeySpec(Crypto.pbkdf2(password, salt, iterations), "AES")
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                val plain = try {
                    cipher.doFinal(data)
                } catch (e: GeneralSecurityException) {
                    throw WrongPassword()
                }
                JSONArray(String(plain, Charsets.UTF_8))
            } else {
                root.getJSONArray("notes")
            }
            return (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Note(
                    id = 0,
                    uid = o.getString("uid"),
                    title = o.optString("title"),
                    body = o.optString("body"),
                    todosJson = o.optJSONArray("todos")?.toString() ?: "[]",
                    pinned = o.optBoolean("pinned"),
                    locked = o.optBoolean("locked"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                )
            }
        } catch (e: JSONException) {
            throw BadBackup("ملف تالف")
        }
    }
}
