package com.mofakkira.notes

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import androidx.fragment.app.FragmentActivity
import com.mofakkira.notes.ui.AppNav
import com.mofakkira.notes.ui.DeepLink
import com.mofakkira.notes.ui.NotesTheme

// FragmentActivity مطلوب لـ BiometricPrompt
class MainActivity : FragmentActivity() {
    companion object {
        const val EXTRA_NOTE = "note_id"
        const val EXTRA_TIMER = "open_timer"
    }

    private val deepLink = mutableStateOf<DeepLink?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handle(intent)
        setContent { NotesTheme { AppNav(deepLink) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i == null || !i.hasExtra(EXTRA_TIMER)) return
        val id = i.getLongExtra(EXTRA_NOTE, -1L)
        deepLink.value = if (i.getBooleanExtra(EXTRA_TIMER, false)) DeepLink.Timer
        else if (id > 0) DeepLink.Note(id) else null
    }
}
