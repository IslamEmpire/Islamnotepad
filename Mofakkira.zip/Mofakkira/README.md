# مفكرتي — تطبيق ملاحظات أندرويد (Kotlin + Compose + Room)

## البناء
1. افتح المجلد في Android Studio (Ladybug أو أحدث) وانتظر المزامنة، أو من الطرفية:
   ```
   gradle wrapper --gradle-version 8.9     # مرة واحدة لتوليد gradlew (يلزم Gradle مثبّت)
   echo "sdk.dir=/مسار/Android/Sdk" > local.properties
   ./gradlew assembleDebug
   ```
2. الناتج: `app/build/outputs/apk/debug/app-debug.apk`

المتطلبات: JDK 17 أو أحدث، Android SDK Platform 35.

## خط Tajawal
حمّل الخط من Google Fonts وضع الملفات التالية في `app/src/main/assets/fonts/`:
`Tajawal-Regular.ttf` و `Tajawal-Medium.ttf` و `Tajawal-Bold.ttf`.
بدونها يعمل التطبيق بالخط الافتراضي.

## ملاحظات
- لا يوجد حذف للرمز السري، فقط تغييره.
- الملاحظات المقفلة تُحفظ في ملف النسخة الاحتياطية كما هي؛ شفّر النسخة بكلمة مرور.
- إن استُرجعت نسخة فيها ملاحظات مقفلة على جهاز بلا رمز، تُفتح حتى يُضبط رمز.

## البناء بدون Android Studio (GitHub Actions)
ارفع المشروع على مستودع GitHub، ثم تبويب Actions ← Build APK ← Run workflow.
بعد انتهائه نزّل `mofakkira-debug-apk` من قسم Artifacts.
